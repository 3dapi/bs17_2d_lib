

#include <windows.h>
#include <stdio.h>
#include "SpLib.h"


int SpLib_CreateWin(int x, int y, int width, int height, char* sName)
{
	printf("Create Window.\n");
	return 0;
}


void SpLib_DestroyWin()
{
	printf("Destroy Window.\n");
}


int	SpLib_Run()
{
	printf("Run Window.\n");
	return 0;
}
