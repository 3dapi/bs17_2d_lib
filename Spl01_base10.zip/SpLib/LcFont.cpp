
#pragma warning(disable: 4996)

#include <vector>

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>

#include "ILcFont.h"
#include "LcFont.h"

#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }



namespace SpLib
{
INT					CLcFont::m_nIDFnt	= 0;		// Font ID
LPDIRECT3DDEVICE9	CLcFont::m_pDevice	= NULL;		// Direct3D Device


CLcFont::CLcFont()
{
	m_nID	= -1;
	m_pFnt	= NULL;
	memset(&m_Dsc, 0, sizeof m_Dsc);
}

CLcFont::~CLcFont()
{
	Destroy();
}

void CLcFont::Destroy()
{
	SAFE_DELETE(	m_pFnt	);
	memset(&m_Dsc, 0, sizeof m_Dsc);
}


INT CLcFont::GetID()
{
	return m_nID;
}

void* CLcFont::GetFont()
{
	return m_pFnt;
}


INT CLcFont::Create(void* p1,void* p2,void* p3,void* p4)
{
	ID3DXFont*	pDXFont	= NULL;
	char*		sName	= (char*)p1;
	LONG		iH		= *((LONG*)p2);
	LONG		iItalic	= *((LONG*)p3);

	D3DXFONT_DESC hFont =
	{
		iH, 0
			, FW_NORMAL, 1
			, iItalic
			, HANGUL_CHARSET, OUT_DEFAULT_PRECIS
			, ANTIALIASED_QUALITY, FF_DONTCARE, "Arial"
	};
	
	strcpy(hFont.FaceName, sName);


    if( FAILED(D3DXCreateFontIndirect( CLcFont::m_pDevice, &hFont, &pDXFont ) ) )
        return -1;


	if(NULL ==pDXFont)
		return -1;

	memcpy(&m_Dsc, &hFont, sizeof m_Dsc);
	m_pFnt = pDXFont;

	// ���ο� ���̵� �ο�
	INT _nID = CLcFont::m_nIDFnt;

	++_nID;

	// overflow....
	if(_nID<0)
	{
		printf("Overflow Font List\n");
		SAFE_RELEASE(	m_pFnt	);
		return -1;
	}


	CLcFont::m_nIDFnt = _nID;
	m_nID = _nID;

	return 0;
}


INT LcDev_FontCreate(char* sCmd
					, ILcFont** pData
					, void* p1
					, void* p2
					, void* p3
					, void* p4
					)
{
	*pData = NULL;

	CLcFont* pObj=new CLcFont;

	if(FAILED(pObj->Create(p1, p2, p3, p4)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}


typedef std::vector<ILcFont* >	lsLcFont;
typedef lsLcFont::iterator		itLcFont;


lsLcFont	m_vFont;			// Font List


INT LcDev_FontInit(void* pDev)
{
	CLcFont::m_pDevice	= (LPDIRECT3DDEVICE9)pDev;

	return 0;
}

void LcDev_FontDestroy()
{
	INT iSize = SpLib::m_vFont.size();
	
	for(INT i=0; i<iSize; ++i)
	{
		SAFE_DELETE( m_vFont[i]	);
	}
	
	m_vFont.clear();
}


ILcFont* LcDev_FontFind(INT _nID)
{
	INT iSize = m_vFont.size();
	INT	nIdx=-1;
	
	for(INT i=0; i<iSize; ++i)
	{
		if(m_vFont[i]->GetID() == _nID)
		{
			nIdx = i;
			break;
		}
	}
	
	if(nIdx<0 || nIdx>=iSize)
	{
		return 0;
	}
	
	return m_vFont[nIdx];
	
}


};// namespace SpLib
////////////////////////////////////////////////////////////////////////////////









INT SpLib_FontCreate(char* sName, LONG iH, LONG iItalic)
{
	SpLib::ILcFont* pFont=NULL;

	if(FAILED(SpLib::LcDev_FontCreate(NULL, &pFont, sName, &iH, &iItalic)))
		return -1;

	SpLib::m_vFont.push_back(pFont);

	return pFont->GetID();
}


INT SpLib_FontDrawText(INT nIdx
					   , LONG lLeft
					   , LONG lTop
					   , LONG lRight
					   , LONG lBottom
					   , DWORD fontColor
					   , const char *format, ...)
{
	INT iSize = SpLib::m_vFont.size();

	if(nIdx<0 || nIdx>=iSize)
		return -1;


	va_list ap;
	char s[1024];

	if (format == NULL)
		return -1;

	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);

	if (s == NULL)
		return -2;

	SpLib::ILcFont*	pFont = SpLib::LcDev_FontFind(nIdx);

	ID3DXFont*	pDxFnt = (ID3DXFont*)pFont->GetFont();

    RECT rc;
	rc.left		= lLeft;
	rc.top		= lTop;
    rc.right	= lRight+20;
	rc.bottom	= lBottom;

    return pDxFnt->DrawText(NULL, s, -1, &rc, 0, fontColor );
}


INT SpLib_FontRelease(INT _nID)
{
	INT iSize = SpLib::m_vFont.size();
	INT	nIdx=-1;

	for(INT i=0; i<iSize; ++i)
	{
		if(SpLib::m_vFont[i]->GetID() == _nID)
		{
			nIdx = i;
			break;
		}
	}

	if(nIdx<0 || nIdx>=iSize)
		return -1;


	SpLib::lsLcFont::iterator	itFont;

	itFont = SpLib::m_vFont.begin() + nIdx;
	SAFE_DELETE( SpLib::m_vFont[nIdx]		);
	SpLib::m_vFont.erase(itFont);

	iSize = SpLib::m_vFont.size();

	return iSize;
}
