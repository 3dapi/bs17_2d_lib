
#pragma comment(lib, "../../lib/LcsLib_.lib")

#include "../../include/LcsLib.h"

#include <stdio.h>


int		iImgW;
int		iImgH;
int		nTx;


int Render()
{
	RECT	rt1 = {0,0,iImgW, iImgH};
	LcsLib_Draw2D(nTx, &rt1);

	VEC2	vcPos(50, 300);
	LcsLib_Draw2D(nTx, &rt1, &vcPos);

	VEC2	vcScl(2, 3);

	vcPos = VEC2(300, 150);
	LcsLib_Draw2D(nTx, &rt1, &vcPos, &vcScl);



	VEC2	vcRot(50, 300);
	FLOAT	fRot = 3.14159f * 45/180;

	vcPos = VEC2(300, 200);
	LcsLib_Draw2D(nTx, &rt1, NULL, &vcScl, &vcRot, fRot, D3DCOLOR_ARGB(128, 128, 255, 255));

	return 0;
}

int main()
{
	printf("�׸� �ø���.......................\n\n");

	//������ �ٲ۴�.
	LcsLib_SetClearColor(0xFF336699);
	LcsLib_CreateWin(100, 100, 800, 600, "My First Game Window");


	// �׸��� ���α׷��� �ε�
	nTx = LcsLib_TextureLoad("Texture/lena.png");
	iImgW = LcsLib_TextureWidth(nTx);
	iImgH = LcsLib_TextureHeight(nTx);


	// ȭ�鿡 ����ϱ� ���ؼ� �Լ��� �����Ѵ�.
	LcsLib_SetRender(Render);
	

	
	
	LcsLib_Run();


	LcsLib_TextureRelease(nTx);

	LcsLib_DestroyWin();

	
	return 0;
}