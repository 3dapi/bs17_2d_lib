//
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#pragma once


#ifndef __STDAFX_H_
#define __STDAFX_H_


#pragma comment(lib, "../../lib/LcsLib_.lib")


#include <windows.h>
#include <stdio.h>	
#include <conio.h>
#include <time.h>

#include "../../include/LcsLib.h"


#include "resource.h"

#include "main.h"

#endif