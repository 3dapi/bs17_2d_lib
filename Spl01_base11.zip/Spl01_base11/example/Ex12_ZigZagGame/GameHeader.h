﻿#pragma once


DWORD GameGetScreenWidth();
DWORD GameGetScreenHeight();
int   GameRender();
int   GameFrameMove();
int   GameInit();
int   GameDestroy();

#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }

// link the 2d game library
#if defined(_DEBUG)
  #pragma comment(lib, "LcsLib_.lib")
#else
  #pragma comment(lib, "LcsLib.lib")
#endif
#include "LcsLib.h"

enum
{
	GAME_INIT = 0,
	GAME_PLAY = 1,
	//GAME_END  = 2,
};
