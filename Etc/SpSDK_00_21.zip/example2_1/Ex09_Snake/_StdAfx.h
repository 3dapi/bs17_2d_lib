//
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __STDAFX_H_
#define __STDAFX_H_


#pragma comment(lib, "McLib_00_21.lib")

#include <windows.h>
#include <stdio.h>	
#include <conio.h>
#include <time.h>

#include <McLib.h>

#include "resource.h"

#include "main.h"

#endif