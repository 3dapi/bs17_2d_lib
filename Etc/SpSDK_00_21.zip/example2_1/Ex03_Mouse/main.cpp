
#pragma comment(lib, "McLib_00_21.lib")

#include <McLib.h>
#include <stdio.h>


int		iImgW;
int		iImgH;
int		nTx;


int Render()
{
	RECT	rt1 = {0,0,iImgW, iImgH};
	McLib_Draw2D(nTx, &rt1);

	return 1;
}


int FrameMove()
{
	int mouseX = McLib_GetMouseX();
	int mouseY = McLib_GetMouseY();
	int mouseZ = McLib_GetMouseZ();

	McLib_SetWindowTitle("%d %d %d", mouseX, mouseY, mouseZ);
	
	return 1;
}


int main()
{
	McLib_SetClearColor(0xFF006699);
	McLib_SetWindowStyle(WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU| WS_VISIBLE);
	
	McLib_CreateWin(100, 100, 800, 600, "McUtil App Lib", false);
	
	nTx = McLib_TextureLoad("Texture/lena.png");
	iImgW = McLib_TextureWidth(nTx);
	iImgH = McLib_TextureHeight(nTx);

	McLib_SetRender(Render);
	McLib_SetFrameMove(FrameMove);

	McLib_Run();

	McLib_DestroyWin();

	
	return 1;
}