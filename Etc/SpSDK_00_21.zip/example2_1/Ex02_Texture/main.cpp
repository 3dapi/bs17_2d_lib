
#pragma comment(lib, "McLib_00_21.lib")

#include <McLib.h>
#include <stdio.h>


int		iImgW;
int		iImgH;
int		nTx;


int Render()
{
	RECT	rt1 = {0,0,iImgW, iImgH};
	McLib_Draw2D(nTx, &rt1);

	VEC2	vcPos(50, 300);
	McLib_Draw2D(nTx, &rt1, &vcPos);

	VEC2	vcScl(2, 3);

	vcPos = VEC2(300, 150);
	McLib_Draw2D(nTx, &rt1, &vcPos, &vcScl);



	VEC2	vcRot(50, 300);
	FLOAT	fRot = 3.14159f * 45/180;

	vcPos = VEC2(300, 200);
	McLib_Draw2D(nTx, &rt1, NULL, &vcScl, &vcRot, fRot, D3DCOLOR_ARGB(128, 128, 255, 255));

	return 1;
}

int main()
{
	printf("�׸� �÷� ����\n\n");

	//������ �ٲ۴�.
	McLib_SetClearColor(0xFF336699);
	McLib_CreateWin(100, 100, 800, 600, "McUtil App Lib", false);


	// �׸��� ���α׷��� �ε�
	nTx = McLib_TextureLoad("Texture/lena.png");
	iImgW = McLib_TextureWidth(nTx);
	iImgH = McLib_TextureHeight(nTx);


	// ȭ�鿡 ����ϱ� ���ؼ� �Լ��� �����Ѵ�.
	McLib_SetRender(Render);
	

	
	
	McLib_Run();


	McLib_TextureRelease(nTx);

	McLib_DestroyWin();

	
	return 1;
}