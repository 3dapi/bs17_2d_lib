
#pragma comment(lib, "McLib_00_21.lib")

#include <McLib.h>
#include <stdio.h>


int FrameMove();
int Render();


// Lena
int		nTx1;
int		iImgW1;
int		iImgH1;


int		nFont1;
int		nFont2;
int		nFont3;


int		mouseX;
int		mouseY;
int		mouseZ;

BYTE*	pKey;


int main()
{
	McLib_SetClearColor(0xFF006699);
	McLib_SetWindowStyle(WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU| WS_VISIBLE);
	
	McLib_CreateWin(100, 100, 800, 600, "���ڿ� ���", false);
	McLib_SetRender(Render);
	McLib_SetFrameMove(FrameMove);

	McLib_SetStateShow(false);// State �����ִ� ���� �����.

	
	nTx1	= McLib_TextureLoad("Texture/lena.png");
	iImgW1	= McLib_TextureWidth(nTx1);
	iImgH1	= McLib_TextureHeight(nTx1);


	nFont1 = McLib_FontCreate("����", 20, 0);
	nFont2 = McLib_FontCreate("Arial", 25, 1);
	nFont3 = McLib_FontCreate("�ü�", 20, 1);

	
	

	McLib_Run();

	
	McLib_DestroyWin();

	
	return 1;
}


int FrameMove()
{
	mouseX = McLib_GetMouseX();
	mouseY = McLib_GetMouseY();
	mouseZ = McLib_GetMouseZ();

	pKey = McLib_GetKeyboard();


	if(pKey[VK_SPACE])
	{
		McLib_ChangeWindow();
	}

	return 1;
}


int Render()
{
	RECT	rt1 = {0,0,iImgW1, iImgH1};

	McLib_Draw2D(nTx1, &rt1);


	McLib_FontDrawText(nFont2, 10, 10, 500, 40, 0xffffFF00
		, "���콺�� ������ ��ư�� ��������!!!");

	
	if( McLib_GetMouseEvent(1))		// R button
	{
		int c= McLib_FontDrawText(nFont3, mouseX, mouseY, mouseX+500, mouseY+ 40
			, 0xffffaaff
			, "Mouse ��ġ: %d %d %d ", mouseX, mouseY, mouseZ);
	}

	return 1;
}