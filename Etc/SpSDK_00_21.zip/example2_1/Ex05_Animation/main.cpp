
#pragma comment(lib, "McLib_00_21.lib")

#include <McLib.h>
#include <stdio.h>


// Lena
int		nTx1;
int		iImgW1;
int		iImgH1;


// Super Mario
int		nTx2;
int		iImgW2;
int		iImgH2;


RECT	m_ImgRc;				// RECT �ִ� �̹���
int		iImgW=50;


DWORD	m_dTimeBegin;				// ���� Ÿ��
DWORD	m_dTimeEnd;					// �� Ÿ��


int FrameMove()
{
	int mouseX = McLib_GetMouseX();
	int mouseY = McLib_GetMouseY();
	int mouseZ = McLib_GetMouseZ();

	BYTE* pKey = McLib_GetKeyboard();

	if( pKey[VK_SPACE])
			McLib_ChangeWindow();


	m_dTimeEnd	= timeGetTime();

	if( (m_dTimeEnd-m_dTimeBegin)>120)
	{
		m_ImgRc.left +=iImgW;

		if(m_ImgRc.left +iImgW >=(int)iImgW2)
			m_ImgRc.left = 0;

		m_ImgRc.right =m_ImgRc.left +iImgW;
		m_dTimeBegin = m_dTimeEnd;
	}
	
	return 1;
}



int Render()
{
	RECT	rt1 = {0,0,iImgW1, iImgH1};

	McLib_Draw2D(nTx1, &rt1);
	McLib_Draw2D(nTx2, &m_ImgRc, &VEC2(300, 300), &VEC2(2, 2));

	return 1;
}

int main()
{
	McLib_SetClearColor(0xFF006699);
	McLib_SetWindowStyle(WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU| WS_VISIBLE);
	
	McLib_CreateWin(100, 100, 800, 600, "McUtil Animation Test", false);
	McLib_SetRender(Render);
	McLib_SetFrameMove(FrameMove);

	nTx1	= McLib_TextureLoad("Texture/lena.png");
	iImgW1	= McLib_TextureWidth(nTx1);
	iImgH1	= McLib_TextureHeight(nTx1);

	nTx2	= McLib_TextureLoad("Texture/mario.png");
	iImgW2	= McLib_TextureWidth(nTx2);
	iImgH2	= McLib_TextureHeight(nTx2);

	SetRect(&m_ImgRc, 0, 0, iImgW, iImgH2);
	
	m_dTimeBegin	=timeGetTime();
	
	
	
	

	McLib_Run();

	McLib_DestroyWin();

	
	return 1;
}