
#pragma comment(lib, "McLib_00_21.lib")

#include <McLib.h>
#include <stdio.h>


struct ImgInfo
{
	int		nTx;
	RECT	rt;
};


int xxxxxx();
int LoadTexture();


INT			g_nImg=0;
ImgInfo*	g_pImg = NULL;

int main()
{
	printf("�׸� �÷� ����\n\n");
	McLib_CreateWin(100, 100, 800, 600, "McUtil App Lib", false);

	LoadTexture();


	// ȭ�鿡 ����ϱ� ���ؼ� �Լ��� �����Ѵ�.
	McLib_SetRender(xxxxxx);
	McLib_Run();


//	McLib_TextureRelease(nTx);

	if(g_pImg)
	{
		free(g_pImg);
		g_nImg	= NULL;
	}

	McLib_DestroyWin();

	
	return 1;
}


int xxxxxx()
{
	int nIdx =1;
	McLib_Draw2D(g_pImg[nIdx].nTx, &g_pImg[nIdx].rt);

	return 1;
}


int LoadTexture()
{
	FILE* fp = fopen("data/img.txt", "rt");

	if(NULL == fp)
		return -1;


	g_nImg=0;
	g_pImg = (ImgInfo*)malloc( sizeof(ImgInfo) * (g_nImg+1));

	char sLine[256];

	while(!feof(fp))
	{
		memset(sLine, 0, sizeof sLine);
		fgets(sLine, sizeof sLine, fp);

		int iLen = strlen(sLine);

		if(iLen && (sLine[iLen-1] =='\n' || sLine[iLen-1] =='\r' ))
		{
			sLine[iLen-1] =0;
		}

		g_pImg[g_nImg].nTx  = McLib_TextureLoad(sLine);
		g_pImg[g_nImg].rt.left	= 0;
		g_pImg[g_nImg].rt.top	= 0;
		g_pImg[g_nImg].rt.right = McLib_TextureWidth(g_pImg[g_nImg].nTx);
		g_pImg[g_nImg].rt.bottom= McLib_TextureHeight(g_pImg[g_nImg].nTx);

		++g_nImg;
		g_pImg = (ImgInfo*) realloc(g_pImg, sizeof(ImgInfo) * (g_nImg+1));
	}

	fclose(fp);


	return 1;
}
