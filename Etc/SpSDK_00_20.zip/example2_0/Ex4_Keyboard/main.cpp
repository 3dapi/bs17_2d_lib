
#pragma comment(lib, "McLib_00_20.lib")

#include <McLib.h>
#include <stdio.h>


DIMG	Img;
PDTX	pTx;


int Render()
{
	RECT	rt1 = {0,0,Img.Width, Img.Height};
	McLib_Draw2D(pTx, &rt1);

	return 1;
}


int FrameMove()
{
	McLib_SetWindowTitle("Change Window Mode. Try to Press Space Bar");


	int mouseX = McLib_GetMouseX();
	int mouseY = McLib_GetMouseY();
	int mouseZ = McLib_GetMouseZ();

	BYTE* pKey = McLib_GetKeyboard();

	for(int i=0; i<256; ++i)
	{
//		if( pKey[i])
//			printf("You Presed %d key!!!\n", i);
	}

	if( pKey[VK_SPACE])
		McLib_ChangeWindow();

	return 1;
}


int main()
{
	McLib_SetClearColor(0xFF006699);
	McLib_SetWindowStyle(WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU| WS_VISIBLE);
	
	McLib_CreateWin(100, 100, 800, 600, "McUtil Keyboard Test", false);
	
	McLib_TextureLoad("Texture/lena.png", pTx, &Img);
	McLib_SetRender(Render);
	McLib_SetFrameMove(FrameMove);

	McLib_Run();

	McLib_DestroyWin();

	
	return 1;
}