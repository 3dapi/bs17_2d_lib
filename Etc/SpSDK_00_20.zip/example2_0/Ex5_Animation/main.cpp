
#pragma comment(lib, "McLib_00_20.lib")

#include <McLib.h>
#include <stdio.h>


DIMG	Img1;
PDTX	pTx1;

DIMG	Img2;
PDTX	pTx2;
RECT	m_ImgRc;				// RECT �ִ� �̹���
int		iImgW=50;


DWORD	m_dTimeBegin;				// ���� Ÿ��
DWORD	m_dTimeEnd;					// �� Ÿ��


int Render()
{
	RECT	rt1 = {0,0,Img1.Width, Img1.Height};

	McLib_Draw2D(pTx1, &rt1);
	
	McLib_Draw2D(pTx2, &m_ImgRc, &VEC2(300, 300), &VEC2(2, 2));

	return 1;
}


int FrameMove()
{
	int mouseX = McLib_GetMouseX();
	int mouseY = McLib_GetMouseY();
	int mouseZ = McLib_GetMouseZ();

	BYTE* pKey = McLib_GetKeyboard();

	if( pKey[VK_SPACE])
			McLib_ChangeWindow();


	m_dTimeEnd	= timeGetTime();

	if( (m_dTimeEnd-m_dTimeBegin)>120)
	{
		m_ImgRc.left +=iImgW;

		if(m_ImgRc.left +iImgW >=(int)Img2.Width)
			m_ImgRc.left = 0;

		m_ImgRc.right =m_ImgRc.left +iImgW;
		m_dTimeBegin = m_dTimeEnd;
	}
	
	return 1;
}


int main()
{
	McLib_SetClearColor(0xFF006699);
	McLib_SetWindowStyle(WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU| WS_VISIBLE);
	
	McLib_CreateWin(100, 100, 800, 600, "McUtil Animation Test", false);
	McLib_SetRender(Render);
	McLib_SetFrameMove(FrameMove);

	McLib_TextureLoad("Texture/lena.png", pTx1, &Img1);
	McLib_TextureLoad("Texture/mario.png", pTx2, &Img2);

	SetRect(&m_ImgRc, 0, 0, iImgW, Img2.Height);
	
	m_dTimeBegin	=timeGetTime();
	
	
	
	

	McLib_Run();

	McLib_DestroyWin();

	
	return 1;
}