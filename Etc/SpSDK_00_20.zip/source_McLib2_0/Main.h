
#ifndef _MAIN_H_
#define _MAIN_H_


class CMain: public CD3DApplication
{
protected:
	ID3DXFont*              m_pD3DXFont;            // D3DX font    
protected:
    virtual HRESULT Init();
	virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalid();

	virtual HRESULT FrameMove();
    virtual HRESULT Render();
    
public:
    LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
    CMain();
};

#endif