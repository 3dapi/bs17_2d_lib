
// �ٸ��콺�� ������ �� ������ �ݵ�� �ʿ�.
#define _WIN32_WINNT 0x0400

#include <vector>

#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "dsound.lib")

#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>

#include "McLib.h"

HINSTANCE	m_hInst;
HWND		m_hWnd;
char		m_sCls[512];

int			m_dScnX;
int			m_dScnY;
int			m_dScnW;
int			m_dScnH;

DWORD		m_dWinStyle	= WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU| WS_VISIBLE;

PD3D		m_pD3D		;			// D3D
PDEV		m_pd3dDevice;			// Device
PDSP		m_pd3dSprite;			// 2D Sprite

DWORD		m_dColor = 0xFF006699;

BYTE		m_KeyCur[256];
int			m_mouseX;
int			m_mouseY;
int			m_mouseZ;
int			m_mouseEvent;


typedef std::vector<ID3DXFont* >	lsDxFont;
typedef lsDxFont::iterator			itDxFont;

lsDxFont			m_vFont	;			// Font








int (*McLib_FrameMove2D)();
int (*McLib_Render2D)();


int (*McLib_Keyboard)(BYTE* key);
int (*McLib_Mouse)(int x, int y, int z, int _event);



int McLib_DefaultFrameMove()
{
	//printf("McLib_Default FrameMove\n");
	return 1;
}

int McLib_DefaultRender()
{
	//printf("McLib_Default Render\n");
	return 1;
}

int McLib_DefaultKeyboard(BYTE* key)
{
	//printf("McLib_Default Keyboard\n");
	return 1;
}

int McLib_DefaultMouse(int x, int y, int z, int _event)
{
	//printf("McLib_Default Mouse\n");
	return 1;
}



void McLib_SetFrameMove( int (*_FrameMove)() )
{
	McLib_FrameMove2D = _FrameMove;
}


void McLib_SetRender( int (*_Render)() )
{
	McLib_Render2D = _Render;
}



void McLib_SetKeyboard( int (*_Keyboard)(BYTE* key) )
{
	McLib_Keyboard	= _Keyboard;
}

void McLib_SetMouse( int (*_Mouse)(int x, int y, int z, int _event) )
{
	McLib_Mouse = _Mouse;
}




int FrameMove2D()
{
	POINT mouse;
	
	memset(m_KeyCur, 0, sizeof(m_KeyCur));

	::GetKeyboardState(m_KeyCur);

	
	for(int i=0; i<256; ++i)
		m_KeyCur[i] = (m_KeyCur[i] & 0x80);
	
	::GetCursorPos(&mouse);
	::ScreenToClient(m_hWnd, &mouse );
	
	m_mouseX = mouse.x;
	m_mouseY = mouse.y;

	McLib_Keyboard(m_KeyCur);
	McLib_Mouse(m_mouseX, m_mouseY, m_mouseZ, 0);

	return McLib_FrameMove2D();
}

int Render3D()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, m_dColor, 1.0f, 0 );
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	if( FAILED( McLib_Render2D() ) )
	{
		m_pd3dDevice->EndScene();
		m_pd3dDevice->Present( 0, 0, 0, 0);
		return 1;
	};

	m_pd3dDevice->EndScene();

	return m_pd3dDevice->Present( 0, 0, 0, 0);
}


LRESULT CALLBACK WndProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	WPARAM wHi = HIWORD(wParam);
	WPARAM wLo = LOWORD(wParam);

	switch(uMsg)
	{
		case WM_MOUSEWHEEL:
		{
			m_mouseZ += short( wHi);

			return 0;
		}
//
//
//		case WM_LBUTTONDOWN	:
//		{
//			m_pInput->SetMouseSt(0, true);
//			return 0;
//		}
//		case WM_LBUTTONUP:
//		{
//			m_pInput->SetMouseSt(1, true);
//			return 0;
//		}
//		case WM_LBUTTONDBLCLK:
//		{
//			m_pInput->SetMouseSt(2, true);
//			return 0;
//		}
//
//		case WM_RBUTTONDOWN	:
//		{
//			m_pInput->SetMouseSt(3, true);
//			return 0;
//		}
//		case WM_RBUTTONUP:
//		{
//			m_pInput->SetMouseSt(4, true);
//			return 0;
//		}
//		case WM_RBUTTONDBLCLK:
//		{
//			m_pInput->SetMouseSt(5, true);
//			return 0;
//		}
//
//		case WM_MBUTTONDOWN	:
//		{
//			m_pInput->SetMouseSt(6, true);
//			return 0;
//		}
//		case WM_MBUTTONUP:
//		{
//			m_pInput->SetMouseSt(7, true);
//			return 0;
//		}
//		case WM_MBUTTONDBLCLK:
//		{
//			m_pInput->SetMouseSt(8, true);
//			return 0;
//		}

		case WM_DESTROY:
		{
			PostQuitMessage(0);
			return 0;
		}
	}

	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}





int McLib_CreateWin(int x, int y, int width, int height, char* sName)
{
	McLib_SetFrameMove( McLib_DefaultFrameMove);
	McLib_SetRender( McLib_DefaultRender );
	McLib_SetKeyboard( McLib_DefaultKeyboard );
	McLib_SetMouse( McLib_DefaultMouse );
	
	strcpy(m_sCls, sName);

	m_dScnX = x;
	m_dScnY = y;
	m_dScnW = width;
	m_dScnH = height;


	m_hInst =(HINSTANCE)GetModuleHandle(NULL);

	WNDCLASS wc;

	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	wc.hInstance=m_hInst;
	wc.lpfnWndProc=(WNDPROC)WndProc;
	wc.lpszClassName=m_sCls;
	wc.lpszMenuName=NULL;
	wc.style=CS_CLASSDC;
	RegisterClass(&wc);


	RECT rc;									//Create the application's window
	
	SetRect( &rc, 0, 0, m_dScnW, m_dScnH);
	AdjustWindowRect( &rc, m_dWinStyle, false );

	
	m_hWnd =CreateWindow( m_sCls, m_sCls
		, m_dWinStyle
		, m_dScnX
		, m_dScnY
		, (rc.right-rc.left)
		, (rc.bottom-rc.top)
		, NULL
		, NULL, m_hInst, NULL );


	// D3D����
	if( NULL == ( m_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
		return -1;
	
	// ����̽��� �����ϱ� ���ؼ��� ������Ʈ �Ķ���� ����ü�� �ʿ�
	// ���� 0���� �����Ѵ��� �Ϻθ� ��������
	
	D3DPRESENT_PARAMETERS d3dpp;
	ZeroMemory( &d3dpp, sizeof(d3dpp) );
	
	d3dpp.Windowed					= TRUE;
	d3dpp.SwapEffect				= D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferFormat			= D3DFMT_X8R8G8B8;
	d3dpp.BackBufferCount			= 2;
	d3dpp.BackBufferWidth			= m_dScnW;
	d3dpp.BackBufferHeight			= m_dScnH;
	d3dpp.EnableAutoDepthStencil	= TRUE;
	d3dpp.AutoDepthStencilFormat	= D3DFMT_D16;
	d3dpp.Flags						= D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;		// Back Buffer�� �̿��Ϸ���..
	
	// D3DADAPTER_DEFAULT: ��κ��� �׷���ī��� ��� ����� ��� �̺κ��� ����
	// D3DDEVTYPE_HAL : �ϵ���� ����(���� ū �ӵ�)�� ���� ���ΰ�.. �ϵ���� ��
	// ���� ���� ��� D3D�� ����Ʈ����� �̸� ��ü �� �� �ִ�.
	
	if( FAILED( m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, m_hWnd,
		D3DCREATE_MIXED_VERTEXPROCESSING, &d3dpp, &m_pd3dDevice ) ) )
	{
		if( FAILED( m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, m_hWnd,
		D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &m_pd3dDevice ) ) )
		{
			m_pd3dDevice->Release();
			m_pD3D->Release();
			return -1;
		}
	}
	
	// DX�� ��������Ʈ�� ����̽��� ������ �Ŀ� ������ �Ѵ�.
	if(FAILED(D3DXCreateSprite(m_pd3dDevice, &m_pd3dSprite)))
	{
		m_pd3dDevice->Release();
		m_pD3D->Release();
		return -1;
	}

	return 1;
}


void McLib_DestroyWin()
{
	int iSize = m_vFont.size();

	for(int i=0; i<iSize; ++i)
	{
		m_vFont[i]->Release();
	}

	if(m_pd3dSprite)
	{
		m_pd3dSprite->Release();
		m_pd3dSprite = NULL;
	}

	if(m_pd3dDevice)
	{
		m_pd3dDevice->Release();
		m_pd3dDevice = NULL;
	}

	if(m_pD3D)
	{
		m_pD3D->Release();
		m_pD3D = NULL;
	}
}


int	McLib_Run()
{
	int hr;

	bool bGotMsg =false;
    MSG  msg;
    msg.message = WM_NULL;
    PeekMessage( &msg, NULL, 0U, 0U, PM_NOREMOVE );

	bool m_bActive = true;


	while( WM_QUIT != msg.message  )
    {
        if( m_bActive )
            bGotMsg = ( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) != 0 );
        else
            bGotMsg = ( GetMessage( &msg, NULL, 0U, 0U ) != 0 );

        if( bGotMsg )
        {
            TranslateMessage( &msg );
            DispatchMessage( &msg );
        }
        else
        {
			if(FAILED(hr = FrameMove2D()))
				break;

			if(FAILED(hr =Render3D()))
				break;
        }
    }

	return 1;
}


BYTE* McLib_GetKeyboard()
{
	return m_KeyCur;
}


int	McLib_GetMouseX()
{
	return m_mouseX;
}


int	McLib_GetMouseY()
{
	return m_mouseY;
}


int	McLib_GetMouseZ()
{
	return m_mouseZ;
}


int	McLib_GetMouseEvent(int nMouse)
{
	if(0 == nMouse)			return m_KeyCur[VK_LBUTTON];
	else if(1 == nMouse)	return m_KeyCur[VK_RBUTTON];
	else if(2 == nMouse)	return m_KeyCur[VK_MBUTTON];
	return 0;
}



HWND	McLib_GetHwnd()		{	return m_hWnd;	}
int		McLib_GetScnW()		{	return m_dScnW;	}
int		McLib_GetScnH()		{	return m_dScnH;	}


void	McLib_SetClearColor(DWORD dC)
{
	m_dColor = dC;
}

DWORD	McLib_GetClearColor()
{
	return m_dColor;
}








int	McLib_TextureLoad(char* sFileName, PDTX& pTx, DIMG* pImg, DWORD dc)
{
	if(FAILED(D3DXCreateTextureFromFileEx(
		m_pd3dDevice
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
		, D3DX_FILTER_NONE
		, D3DX_FILTER_NONE
		, dc
		, pImg
		, NULL
		, &pTx
		)) )
	{
		printf("Create Texture Failed: %s\n", sFileName);
		pTx = NULL;
		return -1;
	}

	return 1;
}


void McLib_TextureRelease(PDTX& pTx)
{
	if(pTx)
	{
		pTx->Release();
		pTx = NULL;
	}
}



void McLib_SetWindowTitle(const char *format, ...)
{
	va_list ap;
	char s[512];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	SetWindowText(m_hWnd, s);
}


void	McLib_SetWindowStyle(DWORD dSty)	{	m_dWinStyle		= dSty;		}
DWORD	McLib_GetWindowStyle()				{	return m_dWinStyle;			}


void McLib_Draw2D(PDTX pSrc, RECT* pSrcRect, VEC2* pTranslation, VEC2* pScaling, VEC2* pRot, FLOAT fAngle, DWORD dC)
{
	m_pd3dSprite->Draw(pSrc, pSrcRect, pScaling, pRot, fAngle, pTranslation, dC);
}




int		McLib_FontCreate(char* sName, LONG iH, BYTE iItalic)
{
	ID3DXFont*	pD3DXFont;
	LOGFONT hFont =
	{
		iH, 0, 0, 0, FW_NORMAL, iItalic
		, FALSE, FALSE,
        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        ANTIALIASED_QUALITY, FF_DONTCARE, "Arial"
	};

	strcpy(hFont.lfFaceName, sName);
	
    if( FAILED(D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &pD3DXFont ) ) )
        return -1;

	m_vFont.push_back(	pD3DXFont);

	return (m_vFont.size()-1);
}



int 	McLib_FontDrawText(int nIdx
						   , LONG lLeft
						   , LONG lTop
						   , LONG lRight
						   , LONG lBottom
						   , DWORD fontColor
						   , const char *format, ...)
{
	int iSize = m_vFont.size();

	if(nIdx<0 || nIdx>=iSize)
		return -1;


	va_list ap;
	char s[1024];
	
	if (format == NULL)
		return -1;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)
		return -2;
	
	ID3DXFont*	pD3DXFont = m_vFont[nIdx];

    RECT rc;
	rc.left		= lLeft;
	rc.top		= lTop;
    rc.right	= lRight+20;
	rc.bottom	= lBottom;

    return pD3DXFont->DrawText( s, -1, &rc, 0, fontColor );
}
