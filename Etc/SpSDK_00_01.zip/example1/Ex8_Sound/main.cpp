
#pragma comment(lib, "McLib_00_01.lib")

#include <McLib.h>
#include <stdio.h>


int FrameMove();
int Render();



DIMG	Img1;
PDTX	pTx1;

int		nFont1;

int		mouseX;
int		mouseY;
int		mouseZ;

BYTE*	pKey;


int		nSound1;


int main()
{
	McLib_SetClearColor(0xFF006699);
	McLib_SetWindowStyle(WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU| WS_VISIBLE);
	
	McLib_CreateWin(100, 100, 800, 600, "Sound ���");
	McLib_SetRender(Render);
	McLib_SetFrameMove(FrameMove);

	McLib_TextureLoad("Texture/lena.png", pTx1, &Img1);
	nFont1 = McLib_FontCreate("Arial", 30, 0);
	
	nSound1 = McLib_SoundLoad("sound/bounce.wav");

	
	

	McLib_Run();

	
	McLib_DestroyWin();

	
	return 1;
}


int FrameMove()
{
	mouseX = McLib_GetMouseX();
	mouseY = McLib_GetMouseY();
	mouseZ = McLib_GetMouseZ();

	pKey = McLib_GetKeyboard();

	
	if(pKey[VK_LEFT] && !McLib_SoundIsPlaying(nSound1))
	{
		McLib_SoundReset(nSound1);
		McLib_SoundPlay(nSound1);
	}


	return 1;
}

int Render()
{
	RECT	rt1 = {0,0,Img1.Width, Img1.Height};

	McLib_Draw2D(pTx1, &rt1);

	int c= McLib_FontDrawText(nFont1, 20, 300, 500, 340
			, 0xffFFAA44, "Tri to Press Left Key");

	
	
	return 1;
}