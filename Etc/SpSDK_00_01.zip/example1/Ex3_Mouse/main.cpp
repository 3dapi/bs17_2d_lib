
#pragma comment(lib, "McLib_00_01.lib")

#include <McLib.h>
#include <stdio.h>


DIMG	Img;
PDTX	pTx;


int Render()
{
	RECT	rt1 = {0,0,Img.Width, Img.Height};
	McLib_Draw2D(pTx, &rt1);

	return 1;
}


int FrameMove()
{
	int mouseX = McLib_GetMouseX();
	int mouseY = McLib_GetMouseY();
	int mouseZ = McLib_GetMouseZ();

	McLib_SetWindowTitle("%d %d %d", mouseX, mouseY, mouseZ);
	
	return 1;
}


int main()
{
	McLib_SetClearColor(0xFF006699);
	McLib_SetWindowStyle(WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU| WS_VISIBLE);
	
	McLib_CreateWin(100, 100, 800, 600, "McUtil App Lib");
	McLib_TextureLoad("Texture/lena.png", pTx, &Img);
	McLib_SetRender(Render);
	McLib_SetFrameMove(FrameMove);

	McLib_Run();

	McLib_DestroyWin();

	
	return 1;
}