
#pragma comment(lib, "McLib_00_01.lib")

#include <McLib.h>
#include <stdio.h>

int main()
{
	printf("Starting McLib\n\n");

	// Create Window
	McLib_CreateWin(100, 100, 800, 600, "McUtil App Lib");
	
	// Run
	McLib_Run();

	//Destroy
	McLib_DestroyWin();
	
	return 1;
}