// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pTx		= NULL;			// ��� �ؽ���
}


INT CMain::Init()
{
	if( FAILED( McTextureLoad("Texture/dx5_logo.bmp", &m_pTx, &m_ImgInf)))
		return -1;

	return 1;
}

void CMain::Destroy()
{
	// ����̽� ���� ������ �ؽ��縦 ����
	SAFE_RELEASE(	m_pTx	);
}


INT CMain::FrameMove()
{
	return 1;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,120,160), 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	RECT	rt1 = {0,0,m_ImgInf.Width, m_ImgInf.Height};
	
	D3DXMATRIX	mtW;
	D3DXMatrixIdentity(&mtW);
	
	m_pd3dSprite->Begin(D3DXSPRITE_ALPHABLEND);


	m_pd3dSprite->Draw(m_pTx, &rt1, NULL, &D3DXVECTOR3(100, 50, 0), D3DXCOLOR(1,1,1,1));							//���� �Ϲ����� ���


	mtW._11 = .5f;
	mtW._22 = .5f;
	mtW._41 = 400;
	mtW._42 = 500;

	m_pd3dSprite->SetTransform(&mtW);
		
	m_pd3dSprite->Draw(m_pTx
				, &rt1
				, NULL
				, NULL
				, D3DXCOLOR(1,1,1,1));

	D3DXMatrixIdentity(&mtW);
	mtW._11 = -0.5f;
	mtW._22 = 0.5f;

	mtW._41 = 550 + m_ImgInf.Width *  (mtW._11<0 ? fabsf(mtW._11) : 0 );
	mtW._42 = 500 + m_ImgInf.Height*  (mtW._22<0 ? fabsf(mtW._22) : 0 );

	m_pd3dSprite->SetTransform(&mtW);
	
	m_pd3dSprite->Draw(m_pTx
				, &rt1
				, NULL
				, NULL
				, D3DXCOLOR(1,1,1,1));




	D3DXMatrixIdentity(&mtW);
	mtW._11 = 0.5f;
	mtW._22 = -0.5f;

	mtW._41 = 400 + m_ImgInf.Width *  (mtW._11<0 ? fabsf(mtW._11) : 0 );
	mtW._42 = 350 + m_ImgInf.Height*  (mtW._22<0 ? fabsf(mtW._22) : 0 );

	m_pd3dSprite->SetTransform(&mtW);
	
	m_pd3dSprite->Draw(m_pTx
				, &rt1
				, NULL
				, NULL
				, D3DXCOLOR(1,1,1,1));





	D3DXMatrixIdentity(&mtW);
	mtW._11 = -0.5f;
	mtW._22 = -0.5f;

	mtW._41 = 550 + m_ImgInf.Width *  (mtW._11<0 ? fabsf(mtW._11) : 0 );
	mtW._42 = 350 + m_ImgInf.Height*  (mtW._22<0 ? fabsf(mtW._22) : 0 );

	m_pd3dSprite->SetTransform(&mtW);
	
	m_pd3dSprite->Draw(m_pTx
				, &rt1
				, NULL
				, NULL
				, D3DXCOLOR(1,1,1,1));

	D3DXMatrixIdentity(&mtW);
	m_pd3dSprite->SetTransform(&mtW);

	m_pd3dSprite->End();


	// EndScene
	m_pd3dDevice->EndScene();

	return 1;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}