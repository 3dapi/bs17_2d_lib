// DsSprite.cpp: implementation of the CDsSprite class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IDsSprite.h"
#include "DsSprite.h"

CDsSprite::CDsSprite()
{
	m_pDev		= NULL;
	m_pSprite	= NULL;
}

CDsSprite::~CDsSprite()
{
	Destroy();
}


INT CDsSprite::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;

	if(FAILED(D3DXCreateSprite(m_pDev, &m_pSprite)))
		return -1;

	return 0;
}

void CDsSprite::Destroy()
{
	if(m_pSprite)
	{
		m_pSprite->Release();
		m_pSprite = NULL;
	}
}

INT CDsSprite::Draw(void* _pTx
					, const SIZE* pImg			// Image Size(width, Height)
					, const RECT* pRC			// Draw Region
					, void* pScl				// Scaling
					, void* pPos				// Position
					, DWORD dColor)
{
	LPDIRECT3DTEXTURE9 pTex = (LPDIRECT3DTEXTURE9)_pTx;

	DWORD	dTexW	= pImg->cx;				// Image Width
	DWORD	dTexH	= pImg->cy;				// Image Size

	FLOAT	fX	= FLOAT(pRC->right - pRC->left);
	FLOAT	fY	= FLOAT(pRC->bottom- pRC->top );

	D3DXMATRIX	mtW;
	D3DXMatrixIdentity(&mtW);
	
	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);

	if(pScl)
	{
		FLOAT*	vScl = (FLOAT*)pScl;
		mtW._11 = vScl[0];
		mtW._22 = vScl[1];
	}

	if(pPos)
	{
		FLOAT*	vPos = (FLOAT*)pPos;
		mtW._41 = vPos[0];
		mtW._42 = vPos[1];
	}

	mtW._41 += fX *  (mtW._11<0 ? fabsf(mtW._11) : 0 );
	mtW._42 += fY *  (mtW._22<0 ? fabsf(mtW._22) : 0 );

	m_pSprite->SetTransform(&mtW);
	
	m_pSprite->Draw(pTex
				, pRC
				, NULL
				, NULL
				, D3DXCOLOR(1,1,1,1));

	D3DXMatrixIdentity(&mtW);
	m_pSprite->SetTransform(&mtW);
	m_pSprite->End();

	return 0;
}


inline INT CDsSprite::LcMath_MakePower2(INT a)
{
	int n=0;
	int t=a;

	while(t)
	{
		t>>=1;
		++n;
	}

	return (0x1<<(n-1) ^ a) ? 0x1<<n : 0x1<<(n-1);
};