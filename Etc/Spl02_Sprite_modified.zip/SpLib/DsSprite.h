// DsSprite.h: interface for the CDsSprite class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _DSSPRITE_H_
#define _DSSPRITE_H_

class CDsSprite : public IDsSprite
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;
	LPD3DXSPRITE			m_pSprite;

public:
	CDsSprite();
	virtual ~CDsSprite();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	
	virtual INT		Draw(void* pTx
						, const SIZE* pImg			// Image Size(width, Height)
						, const RECT* pRC			// Draw Region
						, void* pScl				// Scaling
						, void* pPos				// Position
						, DWORD dColor);

protected:
	inline	INT LcMath_MakePower2(INT a);
};

#endif