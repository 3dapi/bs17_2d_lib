// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pTx		= NULL;			// ��� �ؽ���
	m_pDsSprite	= NULL;
}


INT CMain::Init()
{
	if(FAILED(DsDev_CreateSprite(NULL, &m_pDsSprite, m_pd3dDevice)))
		return -1;

	if( FAILED( McTextureLoad("Texture/mario_all.png", &m_pTx, &m_ImgInf)))
		return -1;

	SetRect(&m_ImgRc,  0,  0,  25, m_ImgInf.Height/2);
	
	m_dTimeBgn	=timeGetTime();

	return 1;
}

void CMain::Destroy()
{
	// ����̽� ���� ������ �ؽ��縦 ����
	SAFE_RELEASE(	m_pTx	);
}


INT CMain::FrameMove()
{
	m_dTimeEnd	= timeGetTime();

	if( (m_dTimeEnd-m_dTimeBgn)>140)
	{
		m_ImgRc.left +=25;

		if(m_ImgRc.left +25 >=450)
			m_ImgRc.left = 0;

		m_ImgRc.right =m_ImgRc.left +25;
		m_dTimeBgn = m_dTimeEnd;
	}


	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,120,160), 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	SIZE	Img={m_ImgInf.Width, m_ImgInf.Height};
	
	m_pDsSprite->Draw(m_pTx, &Img, &m_ImgRc, NULL, &D3DXVECTOR3(100, 50, 0), D3DXCOLOR(1,1,1,1));							//���� �Ϲ����� ���


	m_pDsSprite->Draw(m_pTx, &Img, &m_ImgRc, &D3DXVECTOR2( 4.F,  4.F), &D3DXVECTOR2(400, 500), D3DXCOLOR(1,1,1,1));
	m_pDsSprite->Draw(m_pTx, &Img, &m_ImgRc, &D3DXVECTOR2(-4.F,  4.F), &D3DXVECTOR2(550, 500), D3DXCOLOR(1,1,1,1));

	m_pDsSprite->Draw(m_pTx, &Img, &m_ImgRc, &D3DXVECTOR2( 4.F, -4.F), &D3DXVECTOR2(400, 350), D3DXCOLOR(1,1,1,1));
	m_pDsSprite->Draw(m_pTx, &Img, &m_ImgRc, &D3DXVECTOR2(-4.F, -4.F), &D3DXVECTOR2(550, 350), D3DXCOLOR(1,1,1,1));

	// EndScene
	m_pd3dDevice->EndScene();

	return 1;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}