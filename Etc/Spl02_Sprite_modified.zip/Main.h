// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_

class CMain : public CApplication
{
public:
	D3DXIMAGE_INFO		m_ImgInf;
	LPDIRECT3DTEXTURE9	m_pTx	;

	IDsSprite*			m_pDsSprite;			// 2D Sprite
	
	DWORD				m_dTimeBgn;			// ���� Ÿ��
	DWORD				m_dTimeEnd;			// �� Ÿ��
	
	RECT				m_ImgRc;			// RECT �ִ� �̹���

public:
	CMain();

	virtual INT		Init();
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual INT		Render();

	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);
};

#endif