// Interface for the IDsTexture class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _IDsTexture_H_
#define _IDsTexture_H_


// Image means Orginal Image from File Or Memory.
// Texture means Surface or Colorbuffer Created by Image or Memory.

struct IDsTexture
{
public:
	virtual ~IDsTexture(){};

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;

	virtual INT		Draw( const RECT* pRC			// Draw Region
						, void* pScl				// Scaling
						, void* pPos				// Position
						, DWORD dColor)=0;


	virtual DWORD	GetImageWidth()=0;				// Get Image Width
	virtual DWORD	GetImageHeight()=0;				// Get Image Height
	virtual void	GetImageRect(RECT* rc)=0;		// Get Image RECT
	virtual	void	GetImageInfo(void* p)=0;		// Get D3DXIMAGE_INFO

	virtual void*	GetTexturePointer()=0;			// Get D3DTexture Pointer
};


typedef IDsTexture*		LPDSTEXTURE;

INT	DsDev_CreateTexture(char* cmd					// "File",	"Render Target", or "Memory"
						, IDsTexture** pData
						, void* pDevice				// LPDIRECT3DDEVICE9
						, void* p2					// File Name, RenderTarget, or Memory Pointer
						, void* p3=NULL				// Mip Leve1,	or Width
						, void* p4=NULL				// ColorKey,	or Height
						, void* p5=NULL				// Filter,		or Format
						, void* p6=NULL				// Size for Memory Pointer
						, void* p7=NULL				// No Use
						, void* p8=NULL				// No Use
					);

#endif

