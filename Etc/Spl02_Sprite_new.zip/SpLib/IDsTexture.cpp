// Implementation of the IDsTexture class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IDsTexture.h"
#include "DsTexture.h"



INT	DsDev_CreateTexture(char* cmd					// "File",	"Run Time", or "Memory"
						, IDsTexture** pData
						, void* pDevice				// LPDIRECT3DDEVICE9
						, void* p2					// File Name, RenderTarget, or Memory Pointer
						, void* p3					// Mip Leve1
						, void* p4					// ColorKey
						, void* p5					// Filter
						, void* p6					// Size for Memory Pointer
						, void* p7					// No Use
						, void* p8					// No Use
					)
{
	*pData = NULL;


	if(0 == _stricmp(cmd, "File"))
	{

		CDsTexture*	p = new CDsTexture;
		p->SetCreationOption(0);
		p->SetFileName((char*)p2);

		if(FAILED(p->Create(pDevice, p3, p4, p5)))
		{
			delete p;
			return -1;
		};

		*pData = p;
		return 0;
	}

	else if(0 == _stricmp(cmd, "Render Target"))
	{
		CDsTexture*	p = new CDsTexture;
		p->SetCreationOption(1);
	
		if(FAILED(p->Create(pDevice, p3, p4, p5)))
		{
			delete p;
			return -1;
		};

		*pData = p;
		return 0;
	}

	else if(0 == _stricmp(cmd, "Memory"))
	{
		LONG lMemSize = *((LONG*)p6);

		CDsTexture*	p = new CDsTexture;
		p->SetCreationOption(2);
		p->SetFileName((char*)p2);
		p->SetMemorySize(lMemSize);

		if(FAILED(p->Create(pDevice, p3, p4, p5)))
		{
			delete p;
			return -1;
		};

		*pData = p;
		return 0;
	}

	return -1;
}