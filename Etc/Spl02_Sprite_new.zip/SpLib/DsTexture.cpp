// Implementation of the CDsTexture class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IDsTexture.h"
#include "DsTexture.h"



CDsTexture::CDsTexture()
{
	m_OptCreate	=0;

	m_dColorKey	= 0x0;
	m_dFilter	= D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR;
	m_MemoryL	= 0;
	m_MemoryP	= 0;



	m_pTex		= NULL;
	memset(&m_pImg, 0, sizeof(D3DXIMAGE_INFO));
	
	m_pDev		= NULL;
}

CDsTexture::~CDsTexture()
{
	Destroy();
}


INT CDsTexture::Create(void* p1, void* p2, void* p3, void* p4)
{
	int	hr =0;
	int	i=0;

	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	
	for(i=0; i<4; ++i)
	{
		m_pVtx[i].p.z = (	0.f	);
		m_pVtx[i].p.w = (	1.f	);
	}

	if(0 == m_OptCreate)
	{
		DWORD dMip	= D3DX_DEFAULT;
		
		if(p2)	dMip		= *((DWORD*)p2);
		if(p3)	m_dFilter	= *((DWORD*)p3);
		if(p4)	m_dColorKey	= *((DWORD*)p4);
		
		hr = D3DXCreateTextureFromFileEx( m_pDev
										, m_sFile
										, D3DX_DEFAULT
										, D3DX_DEFAULT
										, dMip
										, 0
										, D3DFMT_UNKNOWN
										, D3DPOOL_MANAGED
										, m_dFilter
										, m_dFilter
										, m_dColorKey
										, &m_pImg
										, NULL
										, &m_pTex);


	}

	else if( 1 == m_OptCreate)
	{
		DWORD	dWidth	= 1024;
		DWORD	dHeight	= 1024;
		DWORD	dFormat	= D3DFMT_A8R8G8B8;

		if(p2)	dWidth	= *((DWORD*)p2);
		if(p3)	dHeight	= *((DWORD*)p3);
		if(p4)	dFormat	= *((DWORD*)p4);
		
		m_pImg.Width	= dWidth;
		m_pImg.Height	= dHeight;
		m_pImg.Format	= (D3DFORMAT)dFormat;

		hr = D3DXCreateTexture(m_pDev, m_pImg.Width, m_pImg.Height, 1, D3DUSAGE_RENDERTARGET, m_pImg.Format, D3DPOOL_DEFAULT, &m_pTex);
	}

	else if( 2 == m_OptCreate)
	{
		DWORD dMip	= D3DX_DEFAULT;
		
		if(p2)	dMip		= *((DWORD*)p2);
		if(p3)	m_dFilter	= *((DWORD*)p3);
		if(p4)	m_dColorKey	= *((DWORD*)p4);

		hr = D3DXCreateTextureFromFileInMemoryEx( m_pDev
										, m_MemoryP
										, m_MemoryL
										, D3DX_DEFAULT
										, D3DX_DEFAULT
										, dMip
										, 0
										, D3DFMT_UNKNOWN
										, D3DPOOL_MANAGED
										, m_dFilter
										, m_dFilter
										, m_dColorKey
										, &m_pImg
										, NULL
										, &m_pTex);
	}

	return hr;
}

void CDsTexture::Destroy()
{
	if(m_pTex)
	{
		m_pTex->Release();
		m_pTex = NULL;
	}
}


INT CDsTexture::Draw( const RECT* pRC			// Draw Region
					, void* pScl				// Scaling
					, void* pPos				// Position
					, DWORD dColor)
{
	DWORD	dTexW	= m_pImg.Width;
	DWORD	dTexH	= m_pImg.Height;

	FLOAT	fScl[2]={1.f, 1.f};
	FLOAT	fPos[2]={0.f, 0.f};

	FLOAT	fX	= FLOAT(pRC->right - pRC->left);
	FLOAT	fY	= FLOAT(pRC->bottom- pRC->top );

	FLOAT	fMaxW = (FLOAT) LcMath_MakePower2(dTexW);
	FLOAT	fMaxH = (FLOAT) LcMath_MakePower2(dTexH);

	m_pVtx[0].u	= (pRC->left+0.5f)/(fMaxW);
	m_pVtx[0].v	= (pRC->top +0.5f)/(fMaxH);

	m_pVtx[3].u	= (pRC->right -0.5F)/(fMaxW);
	m_pVtx[3].v	= (pRC->bottom-0.5F)/(fMaxH);

	m_pVtx[1].u	= m_pVtx[3].u;
	m_pVtx[1].v	= m_pVtx[0].v;

	m_pVtx[2].u	= m_pVtx[0].u;
	m_pVtx[2].v	= m_pVtx[3].v;


	if(pScl)
	{
		FLOAT*	vScl = (FLOAT*)pScl;
		fScl[0]= vScl[0];
		fScl[1]= vScl[1];

		fX	*= fScl[0];
		fY	*= fScl[1];
	}

	if(pPos)
	{
		FLOAT*	vPos = (FLOAT*)pPos;
		fPos[0]= vPos[0];
		fPos[1]= vPos[1];
	}


	m_pVtx[0].p.x = fPos[0]	-0.5f;
	m_pVtx[0].p.y = fPos[1]	-0.5f;

	m_pVtx[1].p.x = m_pVtx[0].p.x + fX	;
	m_pVtx[1].p.y = m_pVtx[0].p.y		;

	m_pVtx[2].p.x = m_pVtx[0].p.x		;
	m_pVtx[2].p.y = m_pVtx[0].p.y + fY	;

	m_pVtx[3].p.x = m_pVtx[0].p.x + fX	;
	m_pVtx[3].p.y = m_pVtx[0].p.y + fY	;

	if(fX<0.f)
	{
		FLOAT	_t = fabsf(fX);
		for(int i=0; i<4; ++i)
		{
			m_pVtx[i].p.x += _t;
		}
	}

	if(fY<0.f)
	{
		FLOAT	_t = fabsf(fY);
		for(int i=0; i<4; ++i)
		{
			m_pVtx[i].p.y += _t;
		}
	}

	m_pVtx[0].d = dColor;
	m_pVtx[1].d = dColor;
	m_pVtx[2].d = dColor;
	m_pVtx[3].d = dColor;


	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);


	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);


	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);


	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	
	
	m_pDev->SetTexture(0, m_pTex);

	m_pDev->SetFVF(CDsTexture::VtxDRHW::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVtx, sizeof (CDsTexture::VtxDRHW));


	m_pDev->SetTexture(0, NULL);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);

	return 0;
}


inline INT CDsTexture::LcMath_MakePower2(INT a)
{
	int n=0;
	int t=a;

	while(t)
	{
		t>>=1;
		++n;
	}

	return (0x1<<(n-1) ^ a) ? 0x1<<n : 0x1<<(n-1);
};



DWORD CDsTexture::GetImageWidth()
{
	return m_pImg.Width;
}

DWORD CDsTexture::GetImageHeight()
{
	return m_pImg.Height;
}

void CDsTexture::GetImageRect(RECT* rc)
{
	rc->left	= 0;
	rc->top		= 0;
	rc->right	= m_pImg.Width;
	rc->bottom	= m_pImg.Height;
}


void CDsTexture::GetImageInfo(void* p)
{
	memcpy(p, &m_pImg, sizeof(D3DXIMAGE_INFO));
}



void* CDsTexture::GetTexturePointer()
{
	return m_pTex;
}


void CDsTexture::SetFileName(char* sFile)
{
	strcpy(m_sFile, sFile);
}



void CDsTexture::SetCreationOption(int nOpt)
{
	m_OptCreate	 = nOpt;
}


void CDsTexture::SetMemorySize(long lSize)
{
	m_MemoryL	= lSize;
}


void CDsTexture::SetMemoryPointer(void* p)
{
	m_MemoryP	= p;
}

