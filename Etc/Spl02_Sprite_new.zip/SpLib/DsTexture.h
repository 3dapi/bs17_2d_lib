// Interface for the CDsTexture class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _DsTexture_H_
#define _DsTexture_H_

class CDsTexture : public IDsTexture
{
protected:
	D3DXIMAGE_INFO		m_pImg		;
	LPDIRECT3DTEXTURE9	m_pTex		;

	INT					m_OptCreate	;		// 0: File, 1: RunTime 2: Memory

	DWORD				m_dColorKey	;
	DWORD				m_dFilter	;

	LONG				m_MemoryL	;		// Memory Size
	void*				m_MemoryP	;		// Memory Pointer
	char				m_sFile[MAX_PATH];	

public:
	struct VtxDRHW
	{
		D3DXVECTOR4		p;
		DWORD			d;
		FLOAT			u,v;

		VtxDRHW(): d(0xFFFFFFFF){};

		enum	{	FVF = (D3DFVF_XYZRHW| D3DFVF_DIFFUSE| D3DFVF_TEX1),	};
	};

protected:
	LPDIRECT3DDEVICE9	m_pDev;
	VtxDRHW				m_pVtx[4];

public:
	CDsTexture();
	virtual ~CDsTexture();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	
	virtual INT		Draw( const RECT* pRC			// Draw Region
						, void* pScl				// Scaling
						, void* pPos				// Position
						, DWORD dColor);


	virtual DWORD	GetImageWidth();				// Get Image Width
	virtual DWORD	GetImageHeight();				// Get Image Height
	virtual void	GetImageRect(RECT* rc);			// Get Image RECT
	virtual	void	GetImageInfo(void* p);			// Get D3DXIMAGE_INFO

	virtual void*	GetTexturePointer();			// Get D3DTexture Pointer

	void	SetFileName(char* sFile);
	void	SetCreationOption(int nOpt);

	void	SetMemorySize(long lSize);
	void	SetMemoryPointer(void* p);

protected:
	inline	INT LcMath_MakePower2(INT a);
};

#endif