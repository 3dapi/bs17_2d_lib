// Implementation of the IDsSprite class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IDsSprite.h"
#include "DsSprite.h"



INT	DsDev_CreateSprite(char* cmd
						, IDsSprite** pData
						, void* pDevice		// LPDIRECT3DDEVICE9
						, void* p2			// No Use
						, void* p3			// No Use
						, void* p4			// No Use
					)
{
	*pData = NULL;

	CDsSprite*	p = new CDsSprite;

	if(FAILED(p->Create(pDevice, p2, p3, p4)))
	{
		delete p;
		return -1;
	};

	*pData = p;
	return 0;
}