// Implementation of the CDsSprite class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IDsTexture.h"
#include "IDsSprite.h"
#include "DsSprite.h"



CDsSprite::CDsSprite()
{
	m_pDev		= NULL;
}

CDsSprite::~CDsSprite()
{
	Destroy();
}


INT CDsSprite::Create(void* p1, void* p2, void* p3, void* p4)
{
	int	i=0;

	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	
	for(i=0; i<4; ++i)
	{
		m_pVtx[i].p.z = (	0.f	);
		m_pVtx[i].p.w = (	1.f	);
	}

	return 0;
}

void CDsSprite::Destroy()
{
}

INT CDsSprite::Draw(void* _pTx					// IDsTexture*
					, const RECT* pRC			// Draw Region
					, void* pScl				// Scaling
					, void* pPos				// Position
					, DWORD dColor)
{
	IDsTexture*			pDs = (IDsTexture*)_pTx;
	LPDIRECT3DTEXTURE9	pTx = (LPDIRECT3DTEXTURE9)pDs->GetTexturePointer();
	SIZE				size;

	size.cx	= pDs->GetImageWidth();
	size.cy	= pDs->GetImageHeight();

	return DrawDxTex(pTx, &size, pRC, pScl, pPos, dColor);
}



INT CDsSprite::DrawDxTex(void* _pTx				// LPDIRECT3DTEXTURE9
					, const SIZE* pImg			// Image Size(width, Height)
					, const RECT* pRC			// Draw Region
					, void* pScl				// Scaling
					, void* pPos				// Position
					, DWORD dColor)
{
	HRESULT hr=0;
	LPDIRECT3DTEXTURE9	pTx = (LPDIRECT3DTEXTURE9)_pTx;
	DWORD	dTexW	= pImg->cx;
	DWORD	dTexH	= pImg->cy;

	FLOAT	fScl[2]={1.f, 1.f};
	FLOAT	fPos[2]={0.f, 0.f};

	FLOAT	fX	= FLOAT(pRC->right - pRC->left);
	FLOAT	fY	= FLOAT(pRC->bottom- pRC->top );

	FLOAT	fMaxW = (FLOAT) LcMath_MakePower2(dTexW);
	FLOAT	fMaxH = (FLOAT) LcMath_MakePower2(dTexH);

	m_pVtx[0].u	= (pRC->left+0.5f)/(fMaxW);
	m_pVtx[0].v	= (pRC->top +0.5f)/(fMaxH);

	m_pVtx[3].u	= (pRC->right -0.5F)/(fMaxW);
	m_pVtx[3].v	= (pRC->bottom-0.5F)/(fMaxH);

	m_pVtx[1].u	= m_pVtx[3].u;
	m_pVtx[1].v	= m_pVtx[0].v;

	m_pVtx[2].u	= m_pVtx[0].u;
	m_pVtx[2].v	= m_pVtx[3].v;


	if(pScl)
	{
		FLOAT*	vScl = (FLOAT*)pScl;
		fScl[0]= vScl[0];
		fScl[1]= vScl[1];

		fX	*= fScl[0];
		fY	*= fScl[1];
	}

	if(pPos)
	{
		FLOAT*	vPos = (FLOAT*)pPos;
		fPos[0]= vPos[0];
		fPos[1]= vPos[1];
	}


	m_pVtx[0].p.x = fPos[0]	-0.5f;
	m_pVtx[0].p.y = fPos[1]	-0.5f;

	m_pVtx[1].p.x = m_pVtx[0].p.x + fX	;
	m_pVtx[1].p.y = m_pVtx[0].p.y		;

	m_pVtx[2].p.x = m_pVtx[0].p.x		;
	m_pVtx[2].p.y = m_pVtx[0].p.y + fY	;

	m_pVtx[3].p.x = m_pVtx[0].p.x + fX	;
	m_pVtx[3].p.y = m_pVtx[0].p.y + fY	;

	if(fX<0.f)
	{
		FLOAT	_t = fabsf(fX);
		for(int i=0; i<4; ++i)
		{
			m_pVtx[i].p.x += _t;
		}
	}

	if(fY<0.f)
	{
		FLOAT	_t = fabsf(fY);
		for(int i=0; i<4; ++i)
		{
			m_pVtx[i].p.y += _t;
		}
	}

	m_pVtx[0].d = dColor;
	m_pVtx[1].d = dColor;
	m_pVtx[2].d = dColor;
	m_pVtx[3].d = dColor;


	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
		
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
	m_pDev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	
	
	hr = m_pDev->SetTexture(0, pTx);
	hr = m_pDev->SetFVF(CDsSprite::VtxDRHW::FVF);
	hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVtx, sizeof (CDsSprite::VtxDRHW));

	m_pDev->SetTexture(0, NULL);

	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	return hr;
}


inline INT CDsSprite::LcMath_MakePower2(INT a)
{
	int n=0;
	int t=a;

	while(t)
	{
		t>>=1;
		++n;
	}

	return (0x1<<(n-1) ^ a) ? 0x1<<n : 0x1<<(n-1);
};



void* CDsSprite::GetDevice()
{
	return m_pDev;
}