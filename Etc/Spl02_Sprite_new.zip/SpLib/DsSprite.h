// Interface for the CDsSprite class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _DsSprite_H_
#define _DsSprite_H_

class CDsSprite : public IDsSprite
{
public:
	struct VtxDRHW
	{
		D3DXVECTOR4		p;
		DWORD			d;
		FLOAT			u,v;

		VtxDRHW(): d(0xFFFFFFFF){};

		enum	{	FVF = (D3DFVF_XYZRHW| D3DFVF_DIFFUSE| D3DFVF_TEX1),	};
	};

protected:
	LPDIRECT3DDEVICE9	m_pDev;
	VtxDRHW				m_pVtx[4];

public:
	CDsSprite();
	virtual ~CDsSprite();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	
	virtual INT		Draw(void* pTx					// IDsTexture*
						, const RECT* pRC			// Draw Region
						, void* pScl				// Scaling
						, void* pPos				// Position
						, DWORD dColor);

	virtual INT		DrawDxTex(void* pTx				// LPDIRECT3DTEXTURE9
						, const SIZE* pImg			// Image Size(width, Height)
						, const RECT* pRC			// Draw Region
						, void* pScl				// Scaling
						, void* pPos				// Position
						, DWORD dColor);

	virtual	void*	GetDevice();					// return	LPDIRECT3DDEVICE9

protected:
	inline	INT LcMath_MakePower2(INT a);
};

#endif