// Interface for the SpriteExam class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _SpriteExam_H_
#define _SpriteExam_H_

class CSpriteExam
{
protected:
	LPDIRECT3DDEVICE9	m_pDev			;
	IDsSprite*			m_pSprite		;

public:
	LPDSTEXTURE			m_hp_pTx		;		//M_hp01.png ��
	LPDSTEXTURE			m_mp_pTx		;		//M_mp01.png ��
	
	LPDSTEXTURE			m_time01_pTx	;		//time01.png ��
	LPDSTEXTURE			m_time02_pTx	;		//time02.png ��
	
	LPDSTEXTURE			temp_pTx1		;
	LPDSTEXTURE			temp_pTx2		;


	LPDSTEXTURE			m_MarioTx		;		// Mario Animation
	RECT				m_MarioRc0		;		// Mario Animation RECT �ִ� �̹���
	RECT				m_MarioRc1		;		// Mario Animation RECT �ִ� �̹���
	DWORD				m_dTimeBgn		;		// ���� Ÿ��
	DWORD				m_dTimeEnd		;		// �� Ÿ��
	
public:
	CSpriteExam();
	virtual ~CSpriteExam();

	INT		Create(IDsSprite* pd3dSprite);
	void	Destroy();
	INT		FrameMove();
	void	Render();

};

#endif