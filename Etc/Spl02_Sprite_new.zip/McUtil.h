// Interface for the Utilities.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCUTIL_H_
#define _MCUTIL_H_

#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }

INT	McTextureLoad(TCHAR* sFile, LPDIRECT3DTEXTURE9* pTx,D3DXIMAGE_INFO *pInf=NULL, DWORD dc= 0x0);
#endif