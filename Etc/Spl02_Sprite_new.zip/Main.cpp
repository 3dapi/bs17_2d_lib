// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pSprite		= NULL;
	m_pExSprite		= NULL;
}


INT CMain::Init()
{
	if(FAILED(DsDev_CreateSprite(NULL, &m_pSprite, m_pd3dDevice)))
		return -1;

	m_pExSprite = new CSpriteExam;
	if(m_pExSprite->Create(m_pSprite))
		return -1;

	return 0;
}

void CMain::Destroy()
{
	SAFE_DELETE(	m_pSprite		);
	SAFE_DELETE(	m_pExSprite		);
}


INT CMain::FrameMove()
{
	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,120,160), 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	m_pExSprite->Render();

	// EndScene
	m_pd3dDevice->EndScene();

	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}