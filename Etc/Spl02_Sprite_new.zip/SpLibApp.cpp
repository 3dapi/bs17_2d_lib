// D3D Sprite toturial
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain*	g_pApp;

INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	CMain	app;

	g_pApp = &app;

	if(FAILED(app.Create(hInst)))
		return -1;

	return app.Run();
}