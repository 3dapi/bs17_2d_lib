// Implementation of the CSpriteExam class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CSpriteExam::CSpriteExam()
{	
	m_pDev			= NULL;

	m_hp_pTx		= NULL;
	m_mp_pTx		= NULL;

	temp_pTx1		= NULL;
	temp_pTx2		= NULL;
	
	m_time01_pTx	= NULL;
	m_time02_pTx	= NULL;

	m_MarioTx		= NULL;
}

CSpriteExam::~CSpriteExam()
{
	Destroy();
}

INT CSpriteExam::Create(IDsSprite* pSprite)
{
	m_pSprite	= pSprite;
	m_pDev		= (LPDIRECT3DDEVICE9)m_pSprite->GetDevice();

	HRESULT hr=-1;

	DWORD	dMip		= 1;
	DWORD	dFilter		= D3DX_FILTER_NONE;
	DWORD	dColorKey	= 0x0;

	if(FAILED(DsDev_CreateTexture("File", &m_hp_pTx, m_pDev, "Texture/M_hp01.png", &dMip, &dFilter, &dColorKey)))
	{
		MessageBox(0, "Create Texture Texture/M_hp01.png Load Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	//M_hp02.png�� �����´�.
	if(FAILED(DsDev_CreateTexture("File", &temp_pTx1, m_pDev, "Texture/M_hp02.png", &dMip, &dFilter, &dColorKey)))
	{
		MessageBox(0, "Create Texture Texture/M_hp02.png Load Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
 	}


	//������MP�� �ؽ�ó�� �����´�.
	//M_mp01.png�� �����´�.

	if(FAILED(DsDev_CreateTexture("File", &m_mp_pTx, m_pDev, "Texture/M_mp01.png", &dMip, &dFilter, &dColorKey)))
	{
		MessageBox(0, "Create Texture Texture/M_mp01.png Load Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	//M_mp02.png�� �����´�.
	if(FAILED(DsDev_CreateTexture("File", &temp_pTx2, m_pDev, "Texture/M_mp02.png", &dMip, &dFilter, &dColorKey)))
	{
		MessageBox(0, "Create Texture Texture/M_mp02.png Load Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	
	//�ð��� �ؽ�ó�� �����´�.
	//time01.png�� �����´�.
	if(FAILED(DsDev_CreateTexture("File", &m_time01_pTx, m_pDev, "Texture/time01.png", &dMip, &dFilter, &dColorKey)))
	{
		MessageBox(0, "Create Texture Texture/time01.png Load Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	//time02.png�� �����´�.
	if(FAILED(DsDev_CreateTexture("File", &m_time02_pTx, m_pDev, "Texture/time02.png", &dMip, &dFilter, &dColorKey)))
	{
		MessageBox(0, "Create Texture Texture/time02.png Load Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}





	// ������ �ִϸ��̼�
	dColorKey = 0x00FFFFFF;

	if(FAILED(DsDev_CreateTexture("File", &m_MarioTx, m_pDev, "Texture/mario_all.png", &dMip, &dFilter, &dColorKey)))
	{
		MessageBox(0, "Create Texture Texture/mario_all.png Load Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	SetRect(&m_MarioRc0,  0,  0,  25, m_MarioTx->GetImageHeight()/2);
	SetRect(&m_MarioRc1,  0,  m_MarioTx->GetImageHeight()/2,  25, m_MarioTx->GetImageHeight());
	
	m_dTimeBgn	=timeGetTime();


	return 0;
}

void CSpriteExam::Destroy()
{
	SAFE_DELETE(	m_hp_pTx		);
	SAFE_DELETE(	m_mp_pTx		);

	SAFE_DELETE(	temp_pTx1		);
	SAFE_DELETE(	temp_pTx2		);

	SAFE_DELETE(	m_time01_pTx	);
	SAFE_DELETE(	m_time02_pTx	);


	SAFE_DELETE(	m_MarioTx	);
}


INT	CSpriteExam::FrameMove()
{
	m_dTimeEnd	= timeGetTime();

	if( (m_dTimeEnd-m_dTimeBgn)>140)
	{
		m_MarioRc0.left +=25;
		m_MarioRc1.left +=25;

		if(m_MarioRc0.left +25 >=450)
		{
			m_MarioRc0.left = 0;
			m_MarioRc1.left = 0;
		}

		m_MarioRc0.right =m_MarioRc0.left +25;
		m_MarioRc1.right =m_MarioRc1.left +25;

		m_dTimeBgn = m_dTimeEnd;
	}

	return 0;
}

void	CSpriteExam::Render()
{
	RECT	rc;

	//M_hp01.png�� �׸���.
	m_hp_pTx->GetImageRect(&rc);
	m_pSprite->Draw(m_hp_pTx
				, &rc
				, NULL
				, &D3DXVECTOR2(30.f,30.f)
				, D3DXCOLOR(1,1,1,1));

		
	//M_hp02.png�� ȭ�鿡 ����Ѵ�.
	temp_pTx1->GetImageRect(&rc);
	m_pSprite->Draw(temp_pTx1
				, &rc
				, NULL
				, &D3DXVECTOR2(33.f,32.f)
				, D3DXCOLOR(1,1,1,1) );
	
	//M_mp01.png�� �׸���.
	m_mp_pTx->GetImageRect(&rc);
	m_pSprite->Draw(m_mp_pTx
				, &rc
				, NULL
				, &D3DXVECTOR3(30.f,70.f,0.f)
				, D3DXCOLOR(1,1,1,1));
	
	//M_mp02.png�� �׸���.
	temp_pTx2->GetImageRect(&rc);
	m_pSprite->Draw(temp_pTx2
				, &rc
				, NULL
				, &D3DXVECTOR3(33.f,72.f,0.f)
				, D3DXCOLOR(1,1,1,1) );
	
	

	//time01.png�� �׸���.
	m_time01_pTx->GetImageRect(&rc);
	m_pSprite->Draw(m_time01_pTx
				, &rc
				, NULL
				, &D3DXVECTOR2(700.f,30.f)
				, D3DXCOLOR(1,1,1,1));
	
	
	//time02.png�� �׸���.
	m_time02_pTx->GetImageRect(&rc);
 	m_pSprite->Draw(m_time02_pTx
				, &rc
				, NULL
				, &D3DXVECTOR2(723.f,45.f)
				, D3DXCOLOR(1,1,1,1));






	// for Scale

	//M_hp01.png�� �׸���.
	m_hp_pTx->GetImageRect(&rc);
	m_pSprite->Draw(m_hp_pTx
				, &rc
				, &D3DXVECTOR2(.5f, .5f)	// ������
				, &D3DXVECTOR2(300.f,30.f)
				, D3DXCOLOR(1,1,1,1));

		
	//M_hp02.png�� ȭ�鿡 ����Ѵ�.
	temp_pTx1->GetImageRect(&rc);
	m_pSprite->Draw(temp_pTx1
				, &rc
				, &D3DXVECTOR2(.5f, .5f)	// ������
				, &D3DXVECTOR2(303.f,31.f)
				, D3DXCOLOR(1,1,1,1) );



	//M_mp01.png�� �׸���.
	m_mp_pTx->GetImageRect(&rc);
	m_pSprite->Draw(m_mp_pTx
				, &rc
				, &D3DXVECTOR2(.5f, .5f)	// ������
				, &D3DXVECTOR3(300.f,70.f,0.f)
				, D3DXCOLOR(1,1,1,1));
	
	//M_mp02.png�� �׸���.
	temp_pTx2->GetImageRect(&rc);
	m_pSprite->Draw(temp_pTx2
				, &rc
				, &D3DXVECTOR2(.5f, .5f)	// ������
				, &D3DXVECTOR3(303.f,71.f,0.f)
				, D3DXCOLOR(1,1,1,1) );




	// �������� �׸���.
	m_pSprite->Draw(m_MarioTx, &m_MarioRc1, NULL, &D3DXVECTOR2(100, 300), D3DXCOLOR(1,1,1,1));							//���� �Ϲ����� ���
	m_pSprite->Draw(m_MarioTx, &m_MarioRc1, &D3DXVECTOR2( 2.F,  2.F), &D3DXVECTOR2(140, 300), D3DXCOLOR(1,1,1, 0.7F));
	m_pSprite->Draw(m_MarioTx, &m_MarioRc1, &D3DXVECTOR2( 3.F,  3.F), &D3DXVECTOR2(200, 300), D3DXCOLOR(1,1,1, 0.2F));

	m_pSprite->Draw(m_MarioTx, &m_MarioRc0, &D3DXVECTOR2( 4.F,  4.F), &D3DXVECTOR2(400, 400), D3DXCOLOR(  1.0f,  0.0f,  0.0f, 1));
	m_pSprite->Draw(m_MarioTx, &m_MarioRc0, &D3DXVECTOR2(-4.F,  4.F), &D3DXVECTOR2(550, 400), D3DXCOLOR(  0.0f,  1.0f,  0.0f, 1));

	m_pSprite->Draw(m_MarioTx, &m_MarioRc0, &D3DXVECTOR2( 4.F, -4.F), &D3DXVECTOR2(400, 250), D3DXCOLOR(  0.0f,  0.0f,  1.0f, 1));
	m_pSprite->Draw(m_MarioTx, &m_MarioRc0, &D3DXVECTOR2(-4.F, -4.F), &D3DXVECTOR2(550, 250), D3DXCOLOR(  1.0f,  1.0f,  0.0f, 0.4f));
}