//
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __STDAFX_H_
#define __STDAFX_H_


#define	WINMAIN_BASE_APP



#ifdef	WINMAIN_BASE_APP
//win32�� ������� ������
#pragma comment (linker, "/SUBSYSTEM:WINDOWS") 
#endif

#pragma comment(lib, "../lib/McLib_00_21.lib")

#include <windows.h>
#include <stdio.h>	
#include <conio.h>
#include <time.h>

#include "../include/McLib.h"

#include "resource.h"

#include "main.h"

#endif