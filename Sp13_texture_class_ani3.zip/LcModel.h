//
////////////////////////////////////////////////////////////////////////////////


#ifndef _LcModel_H_
#define _LcModel_H_


#pragma warning(disable: 4786)
#include <vector>


class CLcModel2D : public ILcModel
{
public:

	struct TAniInfo
	{
		DWORD	dTime;				// RECT �ִ� �̹���
		RECT	ImgRc;				// RECT �ִ� �̹���

		TAniInfo(){};
		TAniInfo(DWORD v1, RECT v2)
		{
			dTime = v1;
			ImgRc = v2;
		}
	};

	typedef std::vector<TAniInfo >	lsAniInfo;
	typedef lsAniInfo::iterator		itAniInfo;

protected:
	char					m_sFile[128];
	INT						m_AniTot	;	// Ani Total Number
	DWORD					m_AniDelta	;	// �ð� ����;
	ILcTexture*				m_AniTex	;	// �ִ� �ؽ�ó
	std::vector<TAniInfo >	m_AniLst	;	// Animation List


	//for Rendering
	RECT			m_ImgRc		;	// Rendering RECT
	D3DXVECTOR3		m_vcPos		;	// Rendering Position
	DWORD			m_dColor	;	// color

public:
	CLcModel2D();
	virtual ~CLcModel2D();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual void	Render();
	virtual const char*	GetName();

	virtual	void	SetPos(const FLOAT* =NULL);
	virtual	void	SetColor(const DWORD=0xFFFFFFFF);
	virtual	void	SetRect(void* rc=NULL);
	
 	virtual	INT		FindAniIndex(INT* pOut/*Out*/, DWORD dTimeCur, DWORD dTimeBgn);
	virtual	INT		FindImageRect(void* pOut/*Out*/, INT nIndex);


	static LPD3DXSPRITE				m_pSprite;

	typedef std::vector<ILcModel*>		lsModel;
	typedef lsModel::iterator			itModel;
	
	static lsModel*	m_vModel;
};

ILcModel*	LcDev_ModelFind(char* sFile);


#endif

